To capture screenshots press 'print screen' or 'scroll lock' keys inside the game.
All captures are saved inside this map, in a 16bit (64k color) bmp format.